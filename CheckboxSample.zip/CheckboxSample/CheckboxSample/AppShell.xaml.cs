﻿namespace CheckboxSample;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
